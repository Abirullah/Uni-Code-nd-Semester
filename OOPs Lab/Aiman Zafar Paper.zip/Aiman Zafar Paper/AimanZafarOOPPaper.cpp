#include <iostream>
#include <string>
#include <vector>

using namespace std;

class Person {
public:
    string name;
    int age;
    string gender;
    string contact;
};

class Patient : public Person {
public:
    string id;
    string history;
    string doctor;
};

class Doctor : public Person {
public:
    string id;
    string spec;
    vector<string> patients;

    void addPatient(string pid) {
        patients.push_back(pid);
    }
};

class Appointment {
public:
    string id;
    string patient;
    string doctor;
    string date;
    string time;
    string status;

    void setStatus(string s) {
        status = s;
    }
};

class Bill {
public:
    string id;
    string patient;
    double amount;
    string services;
    bool paid;
};

class Hospital {
public:
    vector<Patient> pats;
    vector<Doctor> docs;
    vector<Appointment> apps;
    vector<Bill> bills;

    void addPatient(Patient p) {
        pats.push_back(p);
    }

    void addDoctor(Doctor d) {
        docs.push_back(d);
    }

    void makeAppointment(Appointment a) {
        apps.push_back(a);
    }

    void makeBill(Bill b) {
        bills.push_back(b);
    }

    void assignDoc(string pid, string did) {
        for (int i = 0; i < pats.size(); i++) {
            if (pats[i].id == pid) {
                pats[i].doctor = did;
            }
        }

        for (int i = 0; i < docs.size(); i++) {
            if (docs[i].id == did) {
                docs[i].addPatient(pid);
            }
        }
    }

    void showPatient(string pid) {
        for (int i = 0; i < pats.size(); i++) {
            if (pats[i].id == pid) {

                cout << "Name: " << pats[i].name << endl;
                cout << "Age: " << pats[i].age << endl;
                cout << "History: " << pats[i].history << endl;
                cout << "Doctor: " << pats[i].doctor << endl;

                cout << "\nAppointments:\n";
                for (int j = 0; j < apps.size(); j++) {
                    if (apps[j].patient == pid) {
                        cout << apps[j].date << " " << apps[j].time << " " << apps[j].status << endl;
                    }
                }

                cout << "\nBills:\n";
                for (int j = 0; j < bills.size(); j++) {
                    if (bills[j].patient == pid) {
                        cout << bills[j].amount << " " << bills[j].services << endl;
                    }
                }

                return;
            }
        }

        cout << "Patient not found\n";
    }
};

int main() {
    Hospital h;
    int choice;

    while (true) {
        cout << "\n1 Add Patient\n2 Add Doctor\n3 Assign Doctor\n4 Appointment\n5 Bill\n6 Show Patient\n7 Exit\n";
        cin >> choice;
        cin.ignore();

        if (choice == 1) {
            Patient p;

            cout << "ID: "; getline(cin, p.id);
            cout << "Name: "; getline(cin, p.name);
            cout << "Age: "; cin >> p.age; cin.ignore();
            cout << "Gender: "; getline(cin, p.gender);
            cout << "Contact: "; getline(cin, p.contact);
            cout << "History: "; getline(cin, p.history);

            h.addPatient(p);
        }

        else if (choice == 2) {
            Doctor d;

            cout << "ID: "; getline(cin, d.id);
            cout << "Name: "; getline(cin, d.name);
            cout << "Age: "; cin >> d.age; cin.ignore();
            cout << "Gender: "; getline(cin, d.gender);
            cout << "Contact: "; getline(cin, d.contact);
            cout << "Spec: "; getline(cin, d.spec);

            h.addDoctor(d);
        }

        else if (choice == 3) {
            string pid, did;
            cout << "Patient ID: "; getline(cin, pid);
            cout << "Doctor ID: "; getline(cin, did);
            h.assignDoc(pid, did);
        }

        else if (choice == 4) {
            Appointment a;

            cout << "ID: "; getline(cin, a.id);
            cout << "Patient ID: "; getline(cin, a.patient);
            cout << "Doctor ID: "; getline(cin, a.doctor);
            cout << "Date: "; getline(cin, a.date);
            cout << "Time: "; getline(cin, a.time);

            a.status = "Scheduled";

            h.makeAppointment(a);
        }

        else if (choice == 5) {
            Bill b;

            cout << "ID: "; getline(cin, b.id);
            cout << "Patient ID: "; getline(cin, b.patient);
            cout << "Amount: "; cin >> b.amount; cin.ignore();
            cout << "Services: "; getline(cin, b.services);

            b.paid = false;

            h.makeBill(b);
        }

        else if (choice == 6) {
            string pid;
            cout << "Patient ID: "; getline(cin, pid);
            h.showPatient(pid);
        }

        else if (choice == 7) {
            break;
        }

        else {
            cout << "Wrong choice\n";
        }
    }

    return 0;
}