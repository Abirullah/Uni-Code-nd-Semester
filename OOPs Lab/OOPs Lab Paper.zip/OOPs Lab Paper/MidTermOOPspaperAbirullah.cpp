#include <iostream>
#include <iomanip>
#include <vector>
#include <string>
#include <limits>

using namespace std;

// ========= UI =========
void clearScreen() {
#ifdef _WIN32
    system("cls");
#else
    system("clear");
#endif
}

void pauseScreen() {
    cout << "\nPress Enter to continue...";
    cin.ignore(numeric_limits<streamsize>::max(), '\n');
}

void line() {
    cout << "====================================================\n";
}

// ========= PERSON =========
class Person {
protected:
    string name, gender, contact;
    int age;

public:
    Person() {}
    Person(string n, int a, string g, string c) {
        name = n;
        age = a;
        gender = g;
        contact = c;
    }

    void display() const {
        cout << left << setw(15) << "Name:" << name << endl;
        cout << left << setw(15) << "Age:" << age << endl;
        cout << left << setw(15) << "Gender:" << gender << endl;
        cout << left << setw(15) << "Contact:" << contact << endl;
    }
};

// ========= PATIENT =========
class Patient : public Person {
    string id, history, doctorID;

public:
    Patient() {}
    Patient(string i, string n, int a, string g, string c, string h)
        : Person(n, a, g, c) {
        id = i;
        history = h;
        doctorID = "Not Assigned";
    }

    string getID() const { return id; }

    void setDoctor(string d) { doctorID = d; }

    void display() const {
        line();
        cout << "PATIENT RECORD\n";
        line();
        cout << left << setw(15) << "Patient ID:" << id << endl;
        Person::display();
        cout << left << setw(15) << "History:" << history << endl;
        cout << left << setw(15) << "Doctor ID:" << doctorID << endl;
        line();
    }
};

// ========= DOCTOR =========
class Doctor : public Person {
    string id, spec;

public:
    Doctor() {}
    Doctor(string i, string n, int a, string g, string c, string s)
        : Person(n, a, g, c) {
        id = i;
        spec = s;
    }

    string getID() const { return id; }

    void display() const {
        line();
        cout << "DOCTOR RECORD\n";
        line();
        cout << left << setw(15) << "Doctor ID:" << id << endl;
        Person::display();
        cout << left << setw(15) << "Specialization:" << spec << endl;
        line();
    }
};

// ========= APPOINTMENT =========
class Appointment {
    string id, pid, did, date, time;

public:
    Appointment(string i, string p, string d, string dt, string t) {
        id = i;
        pid = p;
        did = d;
        date = dt;
        time = t;
    }

    string getPID() const { return pid; }

    void display() const {
        cout << left << setw(15) << "App ID:" << id
             << setw(15) << "Date:" << date
             << setw(10) << "Time:" << time << endl;
    }
};

// ========= BILL =========
class Bill {
    string id, pid, services;
    double amount;

public:
    Bill(string i, string p, double a, string s) {
        id = i;
        pid = p;
        amount = a;
        services = s;
    }

    string getPID() const { return pid; }

    void display() const {
        cout << left << setw(15) << "Bill ID:" << id
             << setw(15) << "Amount:" << amount << endl;
        cout << "Services: " << services << endl;
    }
};

// ========= SYSTEM =========
class Hospital {
    vector<Patient> patients;
    vector<Doctor> doctors;
    vector<Appointment> apps;
    vector<Bill> bills;

public:
    // ===== SIMPLE FIND =====
    int findPatientIndex(string id) {
        for (int i = 0; i < patients.size(); i++) {
            if (patients[i].getID() == id) return i;
        }
        return -1;
    }

    int findDoctorIndex(string id) {
        for (int i = 0; i < doctors.size(); i++) {
            if (doctors[i].getID() == id) return i;
        }
        return -1;
    }

    // ===== FUNCTIONS =====
    void addPatient(Patient p) { patients.push_back(p); }
    void addDoctor(Doctor d) { doctors.push_back(d); }
    void addApp(Appointment a) { apps.push_back(a); }
    void addBill(Bill b) { bills.push_back(b); }

    void assignDoctor(string pid, string did) {
        int pIndex = findPatientIndex(pid);
        int dIndex = findDoctorIndex(did);

        if (pIndex != -1 && dIndex != -1) {
            patients[pIndex].setDoctor(did);
            cout << "Doctor Assigned Successfully!\n";
        } else {
            cout << "Patient or Doctor Not Found!\n";
        }
    }

    void showPatient(string id) {
        int index = findPatientIndex(id);

        if (index == -1) {
            cout << "Patient Not Found!\n";
            return;
        }

        patients[index].display();

        cout << "\nAppointments:\n";
        for (int i = 0; i < apps.size(); i++) {
            if (apps[i].getPID() == id) {
                apps[i].display();
            }
        }

        cout << "\nBills:\n";
        for (int i = 0; i < bills.size(); i++) {
            if (bills[i].getPID() == id) {
                bills[i].display();
            }
        }
    }
};

// ========= MAIN =========
int main() {
    Hospital h;
    int ch;

    do {
        clearScreen();

        line();
        cout << "   SMART HEALTHCARE SYSTEM\n";
        line();
        cout << "1. Add Patient\n";
        cout << "2. Add Doctor\n";
        cout << "3. Assign Doctor\n";
        cout << "4. Appointment\n";
        cout << "5. Bill\n";
        cout << "6. View Patient\n";
        cout << "7. Exit\n";
        line();
        cout << "Choice: ";

        string input;
        getline(cin, input);

        // ===== SAFE INPUT =====
        try {
            ch = stoi(input);
        } catch (...) {
            cout << "Invalid input! Enter number only.\n";
            pauseScreen();
            continue;
        }

        clearScreen();

        string id, name, gender, contact, hist, spec;
        string pid, did, date, time, serv;
        int age;
        double amt;

        switch (ch) {
        case 1:
            cout << "ADD PATIENT\n"; line();
            cout << "ID: "; getline(cin, id);
            cout << "Name: "; getline(cin, name);
            cout << "Age: "; cin >> age;
            cin.ignore();
            cout << "Gender: "; getline(cin, gender);
            cout << "Contact: "; getline(cin, contact);
            cout << "History: "; getline(cin, hist);
            h.addPatient(Patient(id, name, age, gender, contact, hist));
            break;

        case 2:
            cout << "ADD DOCTOR\n"; line();
            cout << "ID: "; getline(cin, id);
            cout << "Name: "; getline(cin, name);
            cout << "Age: "; cin >> age;
            cin.ignore();
            cout << "Gender: "; getline(cin, gender);
            cout << "Contact: "; getline(cin, contact);
            cout << "Specialization: "; getline(cin, spec);
            h.addDoctor(Doctor(id, name, age, gender, contact, spec));
            break;

        case 3:
            cout << "ASSIGN DOCTOR\n"; line();
            cout << "Patient ID: "; getline(cin, pid);
            cout << "Doctor ID: "; getline(cin, did);
            h.assignDoctor(pid, did);
            break;

        case 4:
            cout << "APPOINTMENT\n"; line();
            cout << "ID: "; getline(cin, id);
            cout << "Patient ID: "; getline(cin, pid);
            cout << "Doctor ID: "; getline(cin, did);
            cout << "Date: "; getline(cin, date);
            cout << "Time: "; getline(cin, time);
            h.addApp(Appointment(id, pid, did, date, time));
            break;

        case 5:
            cout << "GENERATE BILL\n"; line();
            cout << "ID: "; getline(cin, id);
            cout << "Patient ID: "; getline(cin, pid);
            cout << "Amount: "; cin >> amt;
            cin.ignore();
            cout << "Services: "; getline(cin, serv);
            h.addBill(Bill(id, pid, amt, serv));
            break;

        case 6:
            cout << "VIEW PATIENT\n"; line();
            cout << "Patient ID: "; getline(cin, pid);
            h.showPatient(pid);
            break;

        case 7:
            cout << "Exiting...\n";
            break;

        default:
            cout << "Invalid choice!\n";
        }

        if (ch != 7) {
            cout << "\nPress Enter to continue...";
            cin.get();
        }

    } while (ch != 7);

    return 0;
}